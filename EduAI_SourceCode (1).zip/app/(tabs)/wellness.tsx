import { ScrollView, Text, View, TouchableOpacity, Animated } from "react-native";
import { useState, useRef, useEffect } from "react";
import { useColors } from "@/hooks/use-colors";
import { ScreenContainer } from "@/components/screen-container";
import * as Haptics from "expo-haptics";

/**
 * Wellness Hub Screen
 */
export default function WellnessScreen() {
  const colors = useColors();
  const [mode, setMode] = useState<"hub" | "breathing" | "timer">("hub");
  const [breathingPhase, setBreathingPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [timerSeconds, setTimerSeconds] = useState(25);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (mode === "breathing") {
      const sequence = [
        { phase: "inhale" as const, duration: 4000 },
        { phase: "hold" as const, duration: 4000 },
        { phase: "exhale" as const, duration: 4000 },
      ];

      let currentPhaseIndex = 0;
      const interval = setInterval(() => {
        const current = sequence[currentPhaseIndex];
        setBreathingPhase(current.phase);

        Animated.sequence([
          Animated.timing(scaleAnim, {
            toValue: 1.5,
            duration: current.duration,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 0,
            useNativeDriver: true,
          }),
        ]).start();

        currentPhaseIndex = (currentPhaseIndex + 1) % sequence.length;
      }, 4000);

      return () => clearInterval(interval);
    }
  }, [mode, scaleAnim]);

  useEffect(() => {
    if (!isTimerRunning) return;

    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          setIsTimerRunning(false);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Hub Mode
  if (mode === "hub") {
    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <Text className="text-2xl font-bold text-foreground mb-2">Wellness Hub</Text>
          <Text className="text-sm text-muted mb-6">Take care of your mental health</Text>

          {/* Breathing Exercise */}
          <TouchableOpacity
            onPress={() => setMode("breathing")}
            className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl p-6 mb-4 border border-border"
          >
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-lg font-semibold text-foreground">Breathing Exercise</Text>
                <Text className="text-sm text-muted mt-1">5 minutes guided breathing</Text>
              </View>
              <Text className="text-4xl">Breathe</Text>
            </View>
          </TouchableOpacity>

          {/* Study Timer */}
          <TouchableOpacity
            onPress={() => setMode("timer")}
            className="bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl p-6 mb-4 border border-border"
          >
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-lg font-semibold text-foreground">Study Timer</Text>
                <Text className="text-sm text-muted mt-1">Pomodoro-style timer</Text>
              </View>
              <Text className="text-4xl">Timer</Text>
            </View>
          </TouchableOpacity>

          {/* Daily Tip */}
          <View className="bg-warning bg-opacity-10 rounded-2xl p-6 mb-4 border border-warning border-opacity-30">
            <Text className="text-sm font-semibold text-warning mb-2">Daily Wellness Tip</Text>
            <Text className="text-sm text-foreground leading-relaxed">
              Take a 5-minute break every 25 minutes of study. Step outside, stretch, or do some deep breathing to recharge your mind.
            </Text>
          </View>

          {/* Mood Tracker */}
          <View className="bg-surface rounded-2xl p-6 border border-border">
            <Text className="text-sm font-semibold text-foreground mb-4">How are you feeling?</Text>
            <View className="flex-row justify-between">
              {["😊", "😐", "😟"].map((emoji, idx) => (
                <TouchableOpacity
                  key={idx}
                  className="items-center"
                  onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
                >
                  <Text className="text-4xl mb-2">{emoji}</Text>
                  <Text className="text-xs text-muted">
                    {["Great", "Okay", "Stressed"][idx]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Disclaimer */}
          <View className="mt-8 p-4 bg-surface rounded-lg border border-border">
            <Text className="text-xs text-muted leading-relaxed">
              This wellness hub provides supportive tips and tools. It is not a substitute for professional mental health care. If you are struggling, please reach out to a counselor or mental health professional.
            </Text>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // Breathing Mode
  if (mode === "breathing") {
    return (
      <ScreenContainer className="p-6">
        <View className="flex-1 items-center justify-center">
          <TouchableOpacity
            onPress={() => setMode("hub")}
            className="absolute top-0 right-0 p-4"
          >
            <Text className="text-2xl">X</Text>
          </TouchableOpacity>

          <Animated.View
            className="w-40 h-40 rounded-full bg-primary items-center justify-center"
            style={{ transform: [{ scale: scaleAnim }] }}
          >
            <Text className="text-white text-center">
              <Text className="text-2xl font-bold">
                {breathingPhase === "inhale"
                  ? "Inhale"
                  : breathingPhase === "hold"
                    ? "Hold"
                    : "Exhale"}
              </Text>
            </Text>
          </Animated.View>

          <Text className="text-lg text-muted mt-8">Follow the circle</Text>
        </View>
      </ScreenContainer>
    );
  }

  // Timer Mode
  return (
    <ScreenContainer className="p-6">
      <View className="flex-1 items-center justify-center">
        <TouchableOpacity
          onPress={() => setMode("hub")}
          className="absolute top-0 right-0 p-4"
        >
          <Text className="text-2xl">X</Text>
        </TouchableOpacity>

        <Text className="text-6xl font-bold text-primary mb-8">
          {formatTime(timerSeconds)}
        </Text>

        <View className="flex-row gap-4 mb-8">
          {[25, 5].map((mins) => (
            <TouchableOpacity
              key={mins}
              onPress={() => {
                setTimerSeconds(mins * 60);
                setIsTimerRunning(false);
              }}
              className={`px-6 py-3 rounded-lg border-2 ${
                timerSeconds === mins * 60
                  ? "bg-primary border-primary"
                  : "bg-surface border-border"
              }`}
            >
              <Text
                className={`font-semibold ${
                  timerSeconds === mins * 60 ? "text-white" : "text-foreground"
                }`}
              >
                {mins}m
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          onPress={() => setIsTimerRunning(!isTimerRunning)}
          className="bg-primary rounded-full w-20 h-20 items-center justify-center"
        >
          <Text className="text-white text-2xl font-bold">
            {isTimerRunning ? "Pause" : "Start"}
          </Text>
        </TouchableOpacity>
      </View>
    </ScreenContainer>
  );
}
