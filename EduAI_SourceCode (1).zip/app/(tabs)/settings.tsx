import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { useState } from "react";
import { useColors } from "@/hooks/use-colors";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { ScreenContainer } from "@/components/screen-container";
import * as Haptics from "expo-haptics";

/**
 * Settings Screen
 */
export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const [isDarkMode, setIsDarkMode] = useState(colorScheme === "dark");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleDarkModeToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIsDarkMode(!isDarkMode);
  };

  const handleNotificationsToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setNotificationsEnabled(!notificationsEnabled);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4 border-b border-border">
          <Text className="text-2xl font-bold text-foreground">Settings</Text>
        </View>

        {/* Preferences */}
        <View className="px-6 py-6">
          <Text className="text-sm font-semibold text-muted uppercase mb-4">Preferences</Text>

          <View className="bg-surface rounded-2xl border border-border overflow-hidden">
            {/* Dark Mode */}
            <View className="flex-row items-center justify-between px-4 py-4 border-b border-border">
              <View>
                <Text className="text-base font-semibold text-foreground">Dark Mode</Text>
                <Text className="text-sm text-muted mt-1">Easy on the eyes</Text>
              </View>
              <Switch
                value={isDarkMode}
                onValueChange={handleDarkModeToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>

            {/* Notifications */}
            <View className="flex-row items-center justify-between px-4 py-4">
              <View>
                <Text className="text-base font-semibold text-foreground">Notifications</Text>
                <Text className="text-sm text-muted mt-1">Study reminders</Text>
              </View>
              <Switch
                value={notificationsEnabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
          </View>
        </View>

        {/* About */}
        <View className="px-6 py-6">
          <Text className="text-sm font-semibold text-muted uppercase mb-4">About</Text>

          <View className="bg-surface rounded-2xl border border-border p-4">
            <View className="mb-4">
              <Text className="text-sm text-muted">App Name</Text>
              <Text className="text-base font-semibold text-foreground mt-1">EduAI</Text>
            </View>
            <View className="mb-4">
              <Text className="text-sm text-muted">Version</Text>
              <Text className="text-base font-semibold text-foreground mt-1">1.0.0</Text>
            </View>
            <View>
              <Text className="text-sm text-muted">Developer</Text>
              <Text className="text-base font-semibold text-foreground mt-1">Ali - MBZUAI</Text>
            </View>
          </View>
        </View>

        {/* Help & Support */}
        <View className="px-6 py-6">
          <Text className="text-sm font-semibold text-muted uppercase mb-4">Help</Text>

          <View className="bg-surface rounded-2xl border border-border overflow-hidden">
            <TouchableOpacity className="flex-row items-center justify-between px-4 py-4 border-b border-border">
              <Text className="text-base font-semibold text-foreground">Send Feedback</Text>
              <Text className="text-xl">→</Text>
            </TouchableOpacity>

            <TouchableOpacity className="flex-row items-center justify-between px-4 py-4 border-b border-border">
              <Text className="text-base font-semibold text-foreground">Privacy Policy</Text>
              <Text className="text-xl">→</Text>
            </TouchableOpacity>

            <TouchableOpacity className="flex-row items-center justify-between px-4 py-4">
              <Text className="text-base font-semibold text-foreground">Terms of Service</Text>
              <Text className="text-xl">→</Text>
            </TouchableOpacity>
          </View>
        </View>


      </ScrollView>
    </ScreenContainer>
  );
}
