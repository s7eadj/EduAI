/** @type {const} */
const themeColors = {
  primary: { light: '#0066FF', dark: '#0066FF' },
  background: { light: '#FFFFFF', dark: '#0F1419' },
  surface: { light: '#F5F7FA', dark: '#1A1F2E' },
  foreground: { light: '#1A1A1A', dark: '#ECEDEE' },
  muted: { light: '#666666', dark: '#9BA1A6' },
  border: { light: '#E0E7FF', dark: '#334155' },
  success: { light: '#10B981', dark: '#6EE7B7' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
