import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useState } from "react";
import { useColors } from "@/hooks/use-colors";
import { ScreenContainer } from "@/components/screen-container";
import * as Haptics from "expo-haptics";

interface Card {
  id: string;
  front: string;
  back: string;
  known: boolean;
}

/**
 * Flashcards Screen
 */
export default function FlashcardsScreen() {
  const colors = useColors();
  const [mode, setMode] = useState<"select" | "study">("select");
  const [cards, setCards] = useState<Card[]>([
    {
      id: "1",
      front: "What is photosynthesis?",
      back: "Process by which plants convert light energy into chemical energy (glucose)",
      known: false,
    },
    {
      id: "2",
      front: "Define mitosis",
      back: "Cell division process that produces two identical daughter cells",
      known: false,
    },
    {
      id: "3",
      front: "What is DNA?",
      back: "Deoxyribonucleic acid - molecule that carries genetic instructions for life",
      known: false,
    },
  ]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const currentCard = cards[currentCardIndex];
  const progress = ((currentCardIndex + 1) / cards.length) * 100;
  const knownCount = cards.filter((c) => c.known).length;

  const handleMarkKnown = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const newCards = [...cards];
    newCards[currentCardIndex].known = true;
    setCards(newCards);
    handleNextCard();
  };

  const handleMarkLearning = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    handleNextCard();
  };

  const handleNextCard = () => {
    if (currentCardIndex < cards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setIsFlipped(false);
    } else {
      setMode("select");
      setCurrentCardIndex(0);
      setIsFlipped(false);
    }
  };

  if (mode === "select") {
    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <Text className="text-2xl font-bold text-foreground mb-2">Study Decks</Text>
          <Text className="text-sm text-muted mb-6">Choose a deck to study</Text>

          <View className="gap-4">
            <TouchableOpacity
              onPress={() => setMode("study")}
              className="bg-surface border border-border rounded-2xl p-6"
            >
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-lg font-semibold text-foreground">Biology 101</Text>
                  <Text className="text-sm text-muted mt-1">{cards.length} cards</Text>
                  <Text className="text-sm text-success mt-2">{knownCount} known</Text>
                </View>
                <Text className="text-4xl">Books</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity className="bg-surface border border-border rounded-2xl p-6 opacity-50">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-lg font-semibold text-foreground">History</Text>
                  <Text className="text-sm text-muted mt-1">8 cards</Text>
                </View>
                <Text className="text-4xl">Book</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity className="bg-surface border border-border rounded-2xl p-6 opacity-50">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="text-lg font-semibold text-foreground">Chemistry</Text>
                  <Text className="text-sm text-muted mt-1">12 cards</Text>
                </View>
                <Text className="text-4xl">Test</Text>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-6">
      <View className="flex-1">
        <View className="mb-8">
          <View className="flex-row justify-between items-center mb-2">
            <Text className="text-sm font-semibold text-foreground">
              Card {currentCardIndex + 1} of {cards.length}
            </Text>
            <Text className="text-sm text-muted">{Math.round(progress)}%</Text>
          </View>
          <View className="h-2 bg-border rounded-full overflow-hidden">
            <View className="h-full bg-primary" style={{ width: `${progress}%` }} />
          </View>
        </View>

        <TouchableOpacity
          onPress={() => setIsFlipped(!isFlipped)}
          className="flex-1 bg-primary rounded-3xl p-8 items-center justify-center mb-8"
        >
          <Text className="text-sm text-white opacity-70 mb-4">
            {isFlipped ? "Answer" : "Question"}
          </Text>
          <Text className="text-2xl font-bold text-white text-center leading-relaxed">
            {isFlipped ? currentCard.back : currentCard.front}
          </Text>
          <Text className="text-sm text-white opacity-70 mt-8">Tap to flip</Text>
        </TouchableOpacity>

        <View className="gap-3">
          <TouchableOpacity
            onPress={handleMarkKnown}
            className="bg-success rounded-lg py-4 items-center"
          >
            <Text className="text-white font-semibold text-lg">Mark as Known</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={handleMarkLearning}
            className="bg-border rounded-lg py-4 items-center"
          >
            <Text className="text-foreground font-semibold text-lg">Keep Learning</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setMode("select")}
            className="bg-surface border border-border rounded-lg py-4 items-center"
          >
            <Text className="text-foreground font-semibold text-lg">Exit</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScreenContainer>
  );
}
