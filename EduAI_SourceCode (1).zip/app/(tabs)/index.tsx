import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useRouter, useFocusEffect } from "expo-router";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useState, useCallback } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const [streak, setStreak] = useState(1);
  const [streakMsg, setStreakMsg] = useState("Welcome to your Day 1");

  useFocusEffect(
    useCallback(() => {
      const updateStreak = async () => {
        try {
          const lastDate = await AsyncStorage.getItem("lastStreakDate");
          const currentStreak = await AsyncStorage.getItem("currentStreak");
          const today = new Date().toDateString();

          if (lastDate === today) {
            const num = parseInt(currentStreak || "1");
            setStreak(num);
            setStreakMsg(`Welcome to your Day ${num}`);
          } else {
            const newNum = parseInt(currentStreak || "0") + 1;
            await AsyncStorage.setItem("lastStreakDate", today);
            await AsyncStorage.setItem("currentStreak", newNum.toString());
            setStreak(newNum);
            setStreakMsg(`Congratulations! Welcome to your Day ${newNum}`);
          }
        } catch (err) {
          console.log("streak error:", err);
        }
      };

      updateStreak();
    }, [])
  );

  const actions = [
    {
      id: "chat",
      title: "Ask Questions",
      desc: "Get help with your studies",
      icon: "💬",
      route: "/chat",
      color: "#0EA5E9",
      textColor: "#FFFFFF",
    },
    {
      id: "quiz",
      title: "Generate Quiz",
      desc: "Test your knowledge",
      icon: "📝",
      route: "/quiz",
      color: "#F59E0B",
      textColor: "#FFFFFF",
    },
    {
      id: "flashcards",
      title: "Study Flashcards",
      desc: "Learn with flashcards",
      icon: "🗂️",
      route: "/flashcards",
      color: "#8B5CF6",
      textColor: "#FFFFFF",
    },
    {
      id: "wellness",
      title: "Wellness Hub",
      desc: "Relax and recharge",
      icon: "💚",
      route: "/wellness",
      color: "#10B981",
      textColor: "#FFFFFF",
    },
  ];

  const handlePress = (route: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(route as any);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="px-6 pt-8 pb-6">
          <Text className="text-4xl font-bold text-foreground">Welcome Back</Text>
          <Text className="text-base text-muted mt-2">Ready to learn today?</Text>
        </View>

        <View className="mx-6 mb-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-6 border-2 border-blue-600">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-sm font-semibold text-white opacity-90">Daily Streak</Text>
              <Text className="text-5xl font-bold text-white mt-2">{streak} days</Text>
              <Text className="text-sm text-white opacity-80 mt-2">{streakMsg}</Text>
            </View>
            <Text className="text-6xl">🔥</Text>
          </View>
        </View>

        <View className="px-6 mb-8">
          <Text className="text-lg font-semibold text-foreground mb-4">Get Started</Text>
          <FlatList
            data={actions}
            scrollEnabled={false}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => handlePress(item.route)}
                activeOpacity={0.8}
                className="mb-4"
              >
                <View
                  className="rounded-2xl p-5 border-2 border-opacity-20 shadow-md"
                  style={{
                    backgroundColor: item.color,
                    borderColor: item.textColor,
                  }}
                >
                  <View className="flex-row items-center">
                    <Text className="text-4xl mr-4">{item.icon}</Text>
                    <View className="flex-1">
                      <Text
                        className="text-lg font-bold"
                        style={{ color: item.textColor }}
                      >
                        {item.title}
                      </Text>
                      <Text
                        className="text-sm mt-1 font-medium opacity-90"
                        style={{ color: item.textColor }}
                      >
                        {item.desc}
                      </Text>
                    </View>
                    <Text style={{ color: item.textColor }} className="text-2xl font-bold">
                      →
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>

        <View className="px-6 pb-8">
          <Text className="text-lg font-semibold text-foreground mb-4">Recent Activity</Text>
          <View className="bg-surface rounded-2xl p-5 border border-border">
            <View className="flex-row items-center justify-between mb-4">
              <View>
                <Text className="text-sm text-muted">Last Quiz</Text>
                <Text className="text-2xl font-bold text-foreground mt-1">85%</Text>
              </View>
              <View>
                <Text className="text-sm text-muted">Cards Studied</Text>
                <Text className="text-2xl font-bold text-foreground mt-1">24</Text>
              </View>
              <View>
                <Text className="text-sm text-muted">Messages</Text>
                <Text className="text-2xl font-bold text-foreground mt-1">12</Text>
              </View>
            </View>
          </View>
        </View>

        <View className="mx-6 mb-8 bg-warning bg-opacity-10 rounded-2xl p-5 border border-warning border-opacity-30">
          <Text className="text-sm font-semibold text-warning">💡 Tip</Text>
          <Text className="text-sm text-foreground mt-2 leading-relaxed">
            Take a 5-minute break every 25 minutes of studying. Your brain will thank you!
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
