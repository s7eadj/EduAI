import { ScrollView, Text, View, TouchableOpacity, TextInput, ActivityIndicator } from "react-native";
import { useState, useRef, useEffect } from "react";
import { useColors } from "@/hooks/use-colors";
import { ScreenContainer } from "@/components/screen-container";
import * as Haptics from "expo-haptics";
import { trpc } from "@/lib/trpc";

interface Message {
  id: string;
  text: string;
  sender: "user" | "assistant";
  timestamp: Date;
}

export default function ChatScreen() {
  const colors = useColors();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  const sendMsg = trpc.chat.sendMessage.useMutation({
    onSuccess: (res) => {
      if (res.success) {
        const text = typeof res.message === "string" ? res.message : "Got a response!";
        const msg: Message = {
          id: Date.now().toString(),
          text: text,
          sender: "assistant",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, msg]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      setLoading(false);
    },
    onError: (err) => {
      console.log("error:", err);
      const msg: Message = {
        id: Date.now().toString(),
        text: "Something went wrong. Try again!",
        sender: "assistant",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, msg]);
      setLoading(false);
    },
  });

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const userMsg: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    sendMsg.mutate({
      message: input,
      history: messages.map((m) => ({
        role: m.sender,
        content: m.text,
      })),
    });
  };

  const clearChat = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setMessages([]);
  };

  const addQuestion = (q: string) => {
    setInput(q);
  };

  return (
    <ScreenContainer className="p-0 flex-1">
      <View className="flex-1 flex-col">
        <View className="px-6 py-4 border-b border-border flex-row items-center justify-between">
          <View>
            <Text className="text-2xl font-bold text-foreground">Ask Questions</Text>
            <Text className="text-xs text-muted mt-1">Get help with anything</Text>
          </View>
          {messages.length > 0 && (
            <TouchableOpacity
              onPress={clearChat}
              className="p-2 rounded-lg bg-surface border border-border"
            >
              <Text className="text-sm text-muted">Clear</Text>
            </TouchableOpacity>
          )}
        </View>

        <ScrollView
          ref={scrollRef}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
          className="flex-1"
          contentContainerStyle={{ padding: 16, gap: 12, flexGrow: 1 }}
        >
          {messages.length === 0 ? (
            <View className="flex-1 items-center justify-center">
              <Text className="text-5xl mb-4">💬</Text>
              <Text className="text-xl font-bold text-foreground mb-2">Hi! What do you need help with?</Text>
              <Text className="text-sm text-muted text-center leading-relaxed px-4 mb-6">
                Ask me anything about your studies. I'm here to help you learn!
              </Text>
              <View className="gap-2 w-full px-4">
                <TouchableOpacity
                  onPress={() => addQuestion("Explain photosynthesis")}
                  className="bg-surface border border-border rounded-lg p-3 active:opacity-70"
                >
                  <Text className="text-sm text-foreground">💡 Explain photosynthesis</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => addQuestion("What are good study tips?")}
                  className="bg-surface border border-border rounded-lg p-3 active:opacity-70"
                >
                  <Text className="text-sm text-foreground">📚 Good study tips</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => addQuestion("Help with math")}
                  className="bg-surface border border-border rounded-lg p-3 active:opacity-70"
                >
                  <Text className="text-sm text-foreground">🔢 Math help</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            messages.map((msg) => (
              <View
                key={msg.id}
                className={`flex-row ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <View
                  className={`max-w-xs rounded-2xl px-4 py-3 ${
                    msg.sender === "user"
                      ? "bg-primary rounded-br-none"
                      : "bg-surface border border-border rounded-bl-none"
                  }`}
                >
                  <Text
                    className={`text-base leading-relaxed ${
                      msg.sender === "user" ? "text-white" : "text-foreground"
                    }`}
                  >
                    {msg.text}
                  </Text>
                  <Text
                    className={`text-xs mt-1 ${
                      msg.sender === "user" ? "text-white opacity-70" : "text-muted"
                    }`}
                  >
                    {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </Text>
                </View>
              </View>
            ))
          )}

          {loading && (
            <View className="flex-row items-center gap-2 mb-2">
              <View className="w-8 h-8 rounded-full bg-surface border border-border items-center justify-center">
                <ActivityIndicator size="small" color={colors.primary} />
              </View>
              <Text className="text-sm text-muted italic">Thinking...</Text>
            </View>
          )}
        </ScrollView>

        <View className="px-6 py-4 border-t border-border bg-background">
          <View className="flex-row gap-3 items-end">
            <TextInput
              value={input}
              onChangeText={setInput}
              placeholder="Ask anything..."
              placeholderTextColor={colors.muted}
              multiline
              maxLength={500}
              className="flex-1 bg-surface border border-border rounded-2xl px-4 py-3 text-foreground"
              editable={!loading}
            />
            <TouchableOpacity
              onPress={handleSend}
              disabled={loading || !input.trim()}
              className={`rounded-full w-12 h-12 items-center justify-center ${
                loading || !input.trim() ? "bg-border opacity-50" : "bg-primary"
              }`}
            >
              <Text className="text-white text-xl font-bold">→</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScreenContainer>
  );
}
