import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  chat: router({
    sendMessage: publicProcedure
      .input(
        z.object({
          message: z.string().min(1),
          history: z.array(z.object({ role: z.string(), content: z.string() })).optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const messages = [
            {
              role: "system",
              content:
                "You are EduAI, a friendly and knowledgeable study assistant. Your style is conversational, concise, and natural - like ChatGPT. Help students with homework, explain concepts, suggest study tips, and provide encouragement. Keep responses friendly and easy to understand. Use simple language. You are NOT a medical professional - if someone mentions mental health concerns, be supportive but suggest they talk to a counselor. Be encouraging and positive!",
            },
            ...(input.history || []),
            { role: "user", content: input.message },
          ];

          const response = await invokeLLM({ messages: messages as any });
          const assistantMessage = response.choices?.[0]?.message?.content || "Hmm, I'm having trouble responding right now. Try asking again!";

          return { success: true, message: assistantMessage, timestamp: new Date().toISOString() };
        } catch (error) {
          console.error("Chat error:", error);
          return { success: false, message: "Oops! Something went wrong. Please try asking again.", timestamp: new Date().toISOString() };
        }
      }),
  }),

  quiz: router({
    generateQuiz: publicProcedure
      .input(
        z.object({
          topic: z.string().min(1),
          difficulty: z.enum(["easy", "medium", "hard"]),
          count: z.number().min(1).max(20),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: "You are a quiz generator that creates fun, educational questions. Make questions that test understanding, not just memorization. Vary the question types. Respond with ONLY valid JSON array - no other text.",
              },
              {
                role: "user",
                content: `Generate ${input.count} ${input.difficulty} difficulty questions about "${input.topic}". Make them interesting and educational. Return ONLY this JSON format with no extra text: [{"question":"Question here?","options":["Option A","Option B","Option C","Option D"],"correct":0,"explanation":"Why this is correct"}]`,
              },
            ],
            response_format: { type: "json_object" },
          });

          const content = response.choices?.[0]?.message?.content;
          if (!content) throw new Error("No response from AI");

          const questions = JSON.parse(typeof content === "string" ? content : JSON.stringify(content));
          return { success: true, questions: Array.isArray(questions) ? questions : [] };
        } catch (error) {
          console.error("Quiz error:", error);
          return { success: false, questions: [], error: "Couldn't generate quiz. Try a different topic!", timestamp: new Date().toISOString() };
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
