# EduAI — Smart Study Assistant Design

## Overview

**EduAI** is an AI-powered mobile study companion that helps students learn smarter and manage academic stress responsibly. It combines an intelligent tutor chatbot, quiz generator, flashcard system, and wellness features—all designed for students preparing for competitive exams or university applications.

**Target User:** Grade 12 students, university applicants, competitive exam prep students  
**Platform:** iOS/Android (Expo)  
**Design Principle:** Clean, focused, one-handed usage on portrait orientation

---

## Screen List

| Screen | Purpose | Key Components |
|--------|---------|-----------------|
| **Onboarding** | Welcome & feature overview | Skip button, Next buttons, visual indicators |
| **Home** | Main hub with quick actions | Tab bar, featured cards, recent activity |
| **AI Tutor Chat** | Chat with AI study assistant | Message list, input field, send button, typing indicator |
| **Quiz Generator** | Create & take AI-generated quizzes | Subject/topic input, quiz display, score screen |
| **Flashcards** | Study with spaced repetition | Card deck, flip animation, progress bar |
| **Wellness Hub** | Stress management & tips | Breathing exercises, motivational tips, study timer |
| **Settings** | App preferences & about | Theme toggle, app info, feedback |

---

## Primary Content & Functionality

### 1. **Onboarding Screen**
- **Content:** Welcome message, feature highlights (AI Tutor, Quizzes, Flashcards, Wellness)
- **Functionality:** Skip to home, proceed through slides, visual indicators of progress
- **Layout:** Full-screen slides with centered text and icons

### 2. **Home Screen**
- **Content:** 
  - Greeting with time-based message ("Good morning, Ali!")
  - Quick action cards (Start Chat, New Quiz, Study Flashcards, Wellness Tips)
  - Recent activity section (last quiz score, recent chat topic)
  - Daily streak counter
- **Functionality:** Navigate to each feature, view recent activity
- **Layout:** ScrollView with cards, tab bar at bottom

### 3. **AI Tutor Chat Screen**
- **Content:** 
  - Chat history with user/assistant messages
  - Input field with placeholder ("Ask me anything about your studies...")
  - Send button (icon-based)
  - Typing indicator when AI is responding
- **Functionality:** 
  - Send messages
  - Receive AI responses (educational focus, not medical advice)
  - Clear chat history
  - Copy responses
- **Layout:** FlatList for messages, fixed input at bottom
- **AI Behavior:** Tutor mode—explains concepts, suggests study strategies, provides motivational support

### 4. **Quiz Generator Screen**
- **Content:**
  - Topic/subject input field
  - Difficulty selector (Easy, Medium, Hard)
  - Number of questions selector (5, 10, 15)
  - "Generate Quiz" button
- **Functionality:**
  - Generate AI quiz on any topic
  - Display questions one at a time
  - Show score and feedback after completion
  - Option to retake or try new topic
- **Layout:** Form on first screen, quiz display with progress bar
- **AI Behavior:** Creates relevant, educational questions with explanations

### 5. **Flashcards Screen**
- **Content:**
  - Deck selector (create new or select existing)
  - Card display (front/back with flip animation)
  - Progress bar (X of Y cards)
  - Action buttons (Mark as known, Mark as learning, Next)
- **Functionality:**
  - Create custom flashcard decks
  - Flip cards to reveal answers
  - Track progress through deck
  - Save decks locally
- **Layout:** Centered card with swipe/tap to flip, bottom action buttons

### 6. **Wellness Hub Screen**
- **Content:**
  - "Breathing Exercise" card (guided 5-min breathing)
  - "Daily Tip" card (motivational/stress-relief tip)
  - "Study Timer" card (Pomodoro-style timer)
  - "Stress Check-in" card (quick mood tracker)
- **Functionality:**
  - Play guided breathing animation
  - Display daily wellness tips
  - Run study timer with notifications
  - Log mood for personal tracking
- **Layout:** ScrollView with large, tappable cards
- **Important:** All tips are supportive, not medical advice. Includes disclaimer.

### 7. **Settings Screen**
- **Content:**
  - Dark/Light mode toggle
  - About app section
  - Send feedback button
  - App version
  - Privacy & disclaimer
- **Functionality:** Toggle theme, view info, send feedback
- **Layout:** Simple list of settings options

---

## Key User Flows

### Flow 1: First-Time User
1. User opens app → Onboarding slides (skip available)
2. Taps "Get Started" → Home screen
3. Sees quick action cards

### Flow 2: Using AI Tutor
1. User taps "Chat with AI Tutor" → Chat screen
2. Types question (e.g., "Explain photosynthesis")
3. AI responds with explanation
4. User can ask follow-up questions or start new topic

### Flow 3: Taking a Quiz
1. User taps "New Quiz" → Quiz setup screen
2. Enters topic (e.g., "Biology"), selects difficulty & question count
3. Taps "Generate" → Quiz loads
4. Answers questions one by one
5. Submits → Sees score & explanations
6. Option to retake or try new topic

### Flow 4: Wellness Break
1. User taps "Wellness Hub" → Hub screen
2. Taps "Breathing Exercise" → Guided 5-min breathing animation
3. Returns to home or continues studying

---

## Color Choices

| Element | Color | Hex | Purpose |
|---------|-------|-----|---------|
| **Primary (Accent)** | Vibrant Blue | #0066FF | Call-to-action buttons, highlights |
| **Background** | Clean White | #FFFFFF | Light mode background |
| **Dark Background** | Deep Navy | #0F1419 | Dark mode background |
| **Surface** | Light Gray | #F5F7FA | Cards, input fields |
| **Text Primary** | Dark Gray | #1A1A1A | Main text |
| **Text Secondary** | Medium Gray | #666666 | Secondary text, labels |
| **Success** | Fresh Green | #10B981 | Quiz scores, completed tasks |
| **Warning** | Warm Orange | #F59E0B | Alerts, important info |
| **Error** | Soft Red | #EF4444 | Errors, destructive actions |
| **AI Message** | Light Blue | #E0F2FE | AI responses in chat |
| **User Message** | Primary Blue | #0066FF | User messages in chat |

---

## Design Principles

1. **Clean & Focused:** Minimal UI, maximum clarity. One primary action per screen.
2. **One-Handed Usage:** All interactive elements within thumb reach (bottom 60% of screen).
3. **iOS-First:** Follows Apple HIG—rounded corners, proper spacing, native components.
4. **Accessible:** High contrast, readable fonts, clear feedback on interactions.
5. **Supportive Tone:** Encouraging language, positive reinforcement, no judgment.
6. **Responsible AI:** Clear disclaimers that AI is educational, not medical advice.

---

## Technical Considerations

- **Local Storage:** Flashcards, quiz history, settings stored locally via AsyncStorage
- **Backend Integration:** AI responses via tRPC + LLM integration (no API keys needed)
- **Animations:** Subtle transitions, card flips, breathing animation (React Native Reanimated)
- **Responsive:** Adapts to different screen sizes (portrait only)
- **Dark Mode:** Full dark mode support via theme context

---

## Success Metrics

- ✅ All core flows work end-to-end
- ✅ AI responses are educational and supportive
- ✅ App feels polished and responsive
- ✅ GitHub repo is well-documented for MBZUAI admissions
- ✅ No crashes or console errors
