import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator } from "react-native";
import { useState } from "react";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function QuizScreen() {
  const colors = useColors();
  const [stage, setStage] = useState("setup");
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium");
  const [count, setCount] = useState("5");
  const [quiz, setQuiz] = useState<any>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(false);

  const generateQuiz = trpc.quiz.generateQuiz.useMutation();

  const handleGenerate = async () => {
    if (!topic.trim()) {
      alert("Please enter a topic");
      return;
    }

    setLoading(true);
    try {
      const res = await generateQuiz.mutateAsync({
        topic: topic,
        difficulty: difficulty as "easy" | "medium" | "hard",
        count: parseInt(count),
      });
      setQuiz(res.questions);
      setStage("quiz");
      setCurrentIdx(0);
      setSelected(null);
      setScore(0);
    } catch (err) {
      console.log("error:", err);
      alert("Failed to generate quiz");
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (idx: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelected(idx);
  };

  const handleNext = () => {
    if (selected === null) {
      alert("Please select an answer");
      return;
    }

    const q = quiz[currentIdx];
    if (q.correctAnswer === q.options[selected]) {
      setScore(score + 1);
    }

    if (currentIdx < quiz.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelected(null);
    } else {
      setStage("results");
    }
  };

  const handleRestart = () => {
    setStage("setup");
    setTopic("");
    setDifficulty("medium");
    setCount("5");
    setQuiz(null);
  };

  const topics: string[] = ["Math", "Biology", "Chemistry", "History", "Physics", "English"];

  if (stage === "setup") {
    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <Text className="text-3xl font-bold text-foreground mb-2">Generate Quiz</Text>
          <Text className="text-sm text-muted mb-8">Pick a topic and difficulty level</Text>

          <Text className="text-lg font-semibold text-foreground mb-3">Topic</Text>
          <View className="gap-2 mb-8">
            {topics.map((t: string) => (
              <TouchableOpacity
                key={t}
                onPress={() => setTopic(t)}
                className={`p-4 rounded-lg border-2 ${
                  topic === t
                    ? "bg-primary border-primary"
                    : "bg-surface border-border"
                }`}
              >
                <Text
                  className={`font-semibold ${
                    topic === t ? "text-white" : "text-foreground"
                  }`}
                >
                  {t}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text className="text-lg font-semibold text-foreground mb-3">Difficulty</Text>
          <View className="flex-row gap-2 mb-8">
            {["easy", "medium", "hard"].map((d: string) => (
              <TouchableOpacity
                key={d}
                onPress={() => setDifficulty(d as "easy" | "medium" | "hard")}
                className={`flex-1 p-3 rounded-lg border-2 ${
                  difficulty === d
                    ? "bg-primary border-primary"
                    : "bg-surface border-border"
                }`}
              >
                <Text
                  className={`text-center font-semibold capitalize ${
                    difficulty === d ? "text-white" : "text-foreground"
                  }`}
                >
                  {d}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text className="text-lg font-semibold text-foreground mb-3">Questions</Text>
          <View className="flex-row gap-2 mb-8">
            {["3", "5", "10"].map((n: string) => (
              <TouchableOpacity
                key={n}
                onPress={() => setCount(n)}
                className={`flex-1 p-3 rounded-lg border-2 ${
                  count === n
                    ? "bg-primary border-primary"
                    : "bg-surface border-border"
                }`}
              >
                <Text
                  className={`text-center font-semibold ${
                    count === n ? "text-white" : "text-foreground"
                  }`}
                >
                  {n}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity
            onPress={handleGenerate}
            disabled={loading}
            className="bg-primary rounded-lg p-4"
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text className="text-white text-center font-bold text-lg">Generate Quiz</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      </ScreenContainer>
    );
  }

  if (stage === "quiz" && quiz) {
    const q = quiz[currentIdx];
    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <View className="mb-6">
            <Text className="text-sm text-muted">
              Question {currentIdx + 1} of {quiz.length}
            </Text>
            <View className="w-full bg-border rounded-full h-2 mt-2">
              <View
                className="bg-primary rounded-full h-2"
                style={{ width: `${((currentIdx + 1) / quiz.length) * 100}%` }}
              />
            </View>
          </View>

          <Text className="text-2xl font-bold text-foreground mb-6">{q.question}</Text>

          <View className="gap-3 mb-8">
            {q.options.map((opt: string, idx: number) => (
              <TouchableOpacity
                key={idx}
                onPress={() => handleAnswer(idx)}
                className={`p-4 rounded-lg border-2 ${
                  selected === idx
                    ? "bg-primary border-primary"
                    : "bg-surface border-border"
                }`}
              >
                <Text
                  className={`font-semibold ${
                    selected === idx ? "text-white" : "text-foreground"
                  }`}
                >
                  {opt}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity
            onPress={handleNext}
            className="bg-primary rounded-lg p-4"
          >
            <Text className="text-white text-center font-bold">
              {currentIdx === quiz.length - 1 ? "Finish" : "Next"}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </ScreenContainer>
    );
  }

  if (stage === "results") {
    const pct = Math.round((score / quiz.length) * 100);
    return (
      <ScreenContainer className="p-6">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <View className="items-center py-12">
            <Text className="text-6xl mb-4">
              {pct >= 80 ? "🎉" : pct >= 60 ? "👍" : "💪"}
            </Text>
            <Text className="text-4xl font-bold text-foreground mb-2">{pct}%</Text>
            <Text className="text-lg text-muted mb-8">
              You got {score} out of {quiz.length} correct
            </Text>

            {pct >= 80 && (
              <Text className="text-center text-foreground mb-8">
                Excellent work! You really know this topic well!
              </Text>
            )}
            {pct >= 60 && pct < 80 && (
              <Text className="text-center text-foreground mb-8">
                Good job! Keep practicing to improve even more.
              </Text>
            )}
            {pct < 60 && (
              <Text className="text-center text-foreground mb-8">
                Nice effort! Review the material and try again.
              </Text>
            )}
          </View>

          <TouchableOpacity
            onPress={handleRestart}
            className="bg-primary rounded-lg p-4"
          >
            <Text className="text-white text-center font-bold">Try Another Quiz</Text>
          </TouchableOpacity>
        </ScrollView>
      </ScreenContainer>
    );
  }
}
